import os, json, asyncio
from aiogram import Bot, Dispatcher, types
from aiogram.filters import Command
from aiogram.types import MenuButtonWebApp, WebAppInfo

BOT_TOKEN = os.environ["BOT_TOKEN"]
ADMIN_ID = int(os.environ["ADMIN_ID"])
WEBAPP_URL = os.environ["WEBAPP_URL"]

bot = Bot(BOT_TOKEN)
dp = Dispatcher()

@dp.message(Command("start"))
async def start(message: types.Message):
    kb = types.InlineKeyboardMarkup(inline_keyboard=[
        [types.InlineKeyboardButton(text="🛒 Открыть 𝑳𝑰𝒁𝑶𝑹𝑮𝑰𝑵 𝑺𝑻𝑶𝑹𝑬", web_app=types.WebAppInfo(url=WEBAPP_URL))],
        [types.InlineKeyboardButton(text="🎥 Обзоры", url=os.getenv("REVIEWS_URL","https://t.me/YOUR_REVIEWS_CHANNEL"))],
        [types.InlineKeyboardButton(text="📢 Наш Telegram", url=os.getenv("CHANNEL_URL","https://t.me/YOUR_TELEGRAM_CHANNEL"))],
    ])
    await message.answer(
        "𝑳𝑰𝒁𝑶𝑹𝑮𝑰𝑵 𝑺𝑻𝑶𝑹𝑬\n\n"
        "🔥 Магазин PUBG аккаунтов\n"
        "🛒 Добавляй товары в корзину\n"
        "💬 Предлагай свою цену\n"
        "🎥 Смотри обзоры перед покупкой",
        reply_markup=kb
    )

@dp.message()
async def web_data(message: types.Message):
    if not message.web_app_data:
        return
    try:
        data = json.loads(message.web_app_data.data)
    except Exception:
        return

    uid = message.from_user.id
    if data.get("type") == "order":
        text = "🛒 НОВЫЙ ЗАКАЗ\n\n"
        for item in data.get("items", []):
            text += f"• {item['title']} — {item['price']} грн.\n"
        text += f"\n💰 Сумма: {data.get('total')} грн.\n👤 ID: {uid}"
        await bot.send_message(ADMIN_ID, text)
        await message.answer("✅ Заказ отправлен. Владелец магазина свяжется с вами.")
    elif data.get("type") == "offer_price":
        await bot.send_message(
            ADMIN_ID,
            f"💬 ПРЕДЛОЖЕНИЕ ЦЕНЫ\n\n"
            f"Товар: {data.get('product')}\n"
            f"Предложение: {data.get('price')}\n"
            f"👤 ID: {uid}"
        )
        await message.answer("✅ Предложение отправлено.")
    elif data.get("type") == "sell_account":
        await bot.send_message(
            ADMIN_ID,
            f"📥 ПРОДАЖА АККАУНТА\n\n"
            f"Название: {data.get('title')}\n"
            f"Желаемая цена: {data.get('price')}\n"
            f"Описание: {data.get('description')}\n"
            f"👤 ID: {uid}"
        )
        await message.answer("✅ Заявка отправлена владельцу.")

async def main():
    await bot.set_chat_menu_button(
        menu_button=MenuButtonWebApp(
            text="🛒 Магазин",
            web_app=WebAppInfo(url=WEBAPP_URL)
        )
    )
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())
